package Language;

public interface Language {
    public String getName();
}
