#!/bin/bash
# 1805125

echo "Four score and seven years ago,     yo"
echo " our big daddy brought forth on  this continent"
echo "  a new nation, conceived in Liberty   n stuff,"
echo "   and dedicated to the proposition"
echo "    that all men are created equal,   playa."
