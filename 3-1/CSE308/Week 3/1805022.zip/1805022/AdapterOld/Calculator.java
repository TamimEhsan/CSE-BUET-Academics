package AdapterOld;

public interface Calculator {
    public int calculateSum(String seperatorType,String fileName);
}
