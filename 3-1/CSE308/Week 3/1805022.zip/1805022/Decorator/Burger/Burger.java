package Decorator.Burger;

public interface Burger {
    public int getPrice();
    public String getOrderDetails();
}
