package Processor;

public class RaspberryPi extends Processor {
    public RaspberryPi(){
        this.name = "Raspberry PI";
        this.price = 7000;
    }
}
