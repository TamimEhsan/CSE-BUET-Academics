package Font;

public interface Font {

    public String getFont();


}
