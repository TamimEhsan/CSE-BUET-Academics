package Processor;

public class ArduinoMega extends Processor {
    public ArduinoMega(){
        this.name = "Arduino Mega";
        this.price = 1120;

    }
}
