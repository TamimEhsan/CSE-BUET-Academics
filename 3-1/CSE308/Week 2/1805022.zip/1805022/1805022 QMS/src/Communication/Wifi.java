package Communication;

public class Wifi extends Communication {
    public Wifi(){
        this.name = "Wifi";
        this.communicator = "WiFi module";
        this.price = 200;
    }
}
