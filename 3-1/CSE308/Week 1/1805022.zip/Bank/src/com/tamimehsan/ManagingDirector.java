package com.tamimehsan;

public class ManagingDirector extends Employee{

    public ManagingDirector() {
        super("MD",true, true, true, true);
    }

}
