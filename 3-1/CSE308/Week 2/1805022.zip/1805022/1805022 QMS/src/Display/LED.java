package Display;

public class LED extends Display {
    public LED(){
        this.name = "LED";
        this.price = 120;
    }
}
