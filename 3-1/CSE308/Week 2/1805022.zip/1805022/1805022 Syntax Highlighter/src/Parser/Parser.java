package Parser;

public interface Parser {
    public String getName();
}
