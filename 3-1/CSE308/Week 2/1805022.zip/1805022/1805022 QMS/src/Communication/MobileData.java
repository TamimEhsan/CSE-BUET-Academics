package Communication;

public class MobileData extends Communication {
    public MobileData(){
        this.name = "Mobile Data";
        this.communicator = "GSM";
        this.price = 100;
    }
}
