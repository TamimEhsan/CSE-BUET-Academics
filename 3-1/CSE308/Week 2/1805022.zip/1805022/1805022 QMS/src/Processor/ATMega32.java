package Processor;

public class ATMega32 extends Processor {
    public ATMega32() {
        this.name = "ATMega32";
        this.price = 325;
    }
}
