package Display;

public class LCD extends Display {
    public LCD(){
        this.name = "LCD";
        this.price = 50;
    }
}
