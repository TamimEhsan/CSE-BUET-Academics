package AdapterOld;

public interface AdvancedCalculator {
    public int calculateSum(String fileName);
}
